"""Fetch a bounded, story-correct TinyStories corpus for Genesis Native AI.

Python stdlib only. No model weights or whole-dataset downloads.
Original dataset: roneneldan/TinyStories (CDLA-Sharing-1.0).
Story-aligned representation: skeskinen/TinyStories-hf (creator-endorsed).
See README.md before redistributing any downloaded data.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import random
import time
import unicodedata
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

DATASET = "skeskinen/TinyStories-hf"
ORIGINAL = "roneneldan/TinyStories"
BASE = "https://datasets-server.huggingface.co/rows"
LICENSE = "CDLA-Sharing-1.0 (inherited from original roneneldan/TinyStories; verify obligations)"


def get_rows(split: str, offset: int, length: int = 100, timeout: float = 25.0) -> dict:
    query = urlencode({"dataset": DATASET, "config": "default", "split": split,
                       "offset": offset, "length": length})
    url = BASE + "?" + query
    request = Request(url, headers={"User-Agent": "GenesisNativeDatasetResearch/0.6", "Accept": "application/json"})
    for attempt in range(3):
        try:
            with urlopen(request, timeout=timeout) as response:
                obj = json.load(response)
                revision = response.headers.get("x-revision")
            if obj.get("partial"):
                raise RuntimeError(f"Dataset API served a partial split for {split}; refusing incomplete sampling")
            if not isinstance(obj.get("rows"), list) or not isinstance(obj.get("num_rows_total"), int):
                raise RuntimeError(f"Dataset API returned unexpected structure: {url}")
            obj["_revision"] = revision
            return obj
        except HTTPError as ex:
            if ex.code not in (500, 502, 503, 504) or attempt == 2:
                raise RuntimeError(f"Dataset API HTTP {ex.code} for {url}") from ex
        except (TimeoutError, URLError) as ex:
            if attempt == 2:
                raise RuntimeError(f"Dataset API network failure for {url}: {ex}") from ex
        time.sleep(1.5 * (attempt + 1))
    raise RuntimeError("unreachable")


def clean_story(value: str) -> str:
    return unicodedata.normalize("NFC", value.replace("\r\n", "\n").replace("\r", "\n")).strip()


def fetch_split(split: str, byte_limit: int, rng: random.Random, seen: set[str],
                used_indices: set[tuple[str, int]], pause: float, output: Path,
                logical_split: str, source_revisions: dict[str, str | None]) -> tuple[list[dict], int]:
    if byte_limit <= 0:
        return [], 0
    # Only one 100-row slice is fetched at once. First page determines population size.
    initial = get_rows(split, 0)
    total_rows = initial["num_rows_total"]
    if total_rows < 1:
        raise RuntimeError(f"Empty source split: {split}")
    revision = initial.get("_revision")
    if split in source_revisions and source_revisions[split] != revision:
        raise RuntimeError("Dataset revision changed during sampling")
    source_revisions[split] = revision
    page_count = math.ceil(total_rows / 100)
    pages = list(range(page_count))
    rng.shuffle(pages)
    docs: list[dict] = []
    collected = 0
    pages_used = 0
    for page in pages:
        if collected >= byte_limit:
            break
        if pages_used >= 100:
            raise RuntimeError(f"100-page safety cap reached for {logical_split}; use a smaller target")
        start = page * 100
        payload = initial if page == 0 else get_rows(split, start, min(100, total_rows - start))
        if payload.get("_revision") != revision or payload.get("num_rows_total") != total_rows:
            raise RuntimeError("Dataset split changed during sampling; refusing mixed revisions")
        pages_used += 1
        for row in payload["rows"]:
            if row.get("truncated_cells"):
                # Do not train on clipped/reconstructed stories.
                continue
            idx = row.get("row_idx")
            key = (split, idx)
            content = row.get("row", {}).get("text")
            if not isinstance(idx, int) or not isinstance(content, str) or key in used_indices:
                continue
            text = clean_story(content)
            if len(text) < 90:
                continue
            encoded = text.encode("utf-8")
            digest = hashlib.sha256(encoded).hexdigest()
            # Exact normalized duplicate removal across train, validation and test.
            if digest in seen:
                continue
            seen.add(digest)
            used_indices.add(key)
            name = f"{logical_split}_{idx:08d}.txt"
            (output / name).write_bytes(encoded)
            docs.append({"file": name, "source": f"{DATASET}/{split} row_idx={idx}; original {ORIGINAL}",
                         "license": LICENSE, "training_permitted": True,
                         "split": logical_split, "sha256": digest, "source_row_idx": idx,
                         "source_split": split, "dataset_revision": revision})
            collected += len(encoded)
            if collected >= byte_limit:
                break
        print(f"{logical_split}: {len(docs)} stories, {collected:,}/{byte_limit:,} bytes", flush=True)
        if pause and collected < byte_limit:
            time.sleep(pause)
    if not docs:
        raise RuntimeError(f"No usable stories collected for {logical_split}")
    return docs, collected


def build(target: Path, size: int, seed: int, pause: float) -> dict:
    if target.exists() and any(target.iterdir()):
        raise FileExistsError(f"Output directory is not empty: {target}. Refusing to overwrite files.")
    target.mkdir(parents=True, exist_ok=True)
    rng = random.Random(seed)
    seen: set[str] = set()
    used: set[tuple[str, int]] = set()
    revisions: dict[str, str | None] = {}
    allocations = {"train": size * 90 // 100, "validation": size * 5 // 100}
    allocations["test"] = size - allocations["train"] - allocations["validation"]
    records: list[dict] = []
    stats = {}
    # Sample training from official train, both holdouts from original validation.
    for logical, physical in (("train", "train"), ("validation", "validation"), ("test", "validation")):
        docs, nbytes = fetch_split(physical, allocations[logical], rng, seen, used, pause, target, logical, revisions)
        records.extend(docs)
        stats[logical] = {"documents": len(docs), "utf8_bytes": nbytes}
    manifest = {"format": "genesis.corpus.v1", "documents": records}
    manifest_path = target / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    # The Genesis corpus loader uses only train/validation; test remains independent.
    summary = {"dataset": DATASET, "original_dataset": ORIGINAL, "license": LICENSE,
               "dataset_revisions": revisions, "seed": seed, "stats": stats,
               "estimated_byte_tokens": sum(item["utf8_bytes"] for item in stats.values()),
               "notes": ["Each row is a whole story in the reprocessed dataset",
                         "Validation and test come from different rows of the original validation split",
                         "Final test split must not be used for model selection",
                         "CDLA obligations apply to any redistribution of extracted stories"]}
    (target / "provenance_summary.json").write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    print("READY:", manifest_path, "\n" + json.dumps(summary, indent=2), flush=True)
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description="Build a bounded TinyStories dataset for original Genesis weights")
    parser.add_argument("--output", default="data/genesis_v0_6_tinystories_1mb")
    parser.add_argument("--target-bytes", type=int, default=1_000_000)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--pause-seconds", type=float, default=0.4)
    opts = parser.parse_args()
    if not 30_000 <= opts.target_bytes <= 5_000_000:
        parser.error("target-bytes must be between 30,000 and 5,000,000")
    if opts.pause_seconds < 0:
        parser.error("pause-seconds cannot be negative")
    build(Path(opts.output), opts.target_bytes, opts.seed, opts.pause_seconds)


if __name__ == "__main__":
    main()
