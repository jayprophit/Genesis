# Genesis v0.6 — bounded TinyStories corpus repair

This package contains a **dataset acquisition helper**, not a pretrained AI model, a completed training run, or a dataset archive. It is designed to run on the Dell workstation without downloading the 1.92 GB text file, and without needing `datasets`, NumPy, or PyTorch for the download itself.

## Why use a different dataset representation?

The original `roneneldan/TinyStories` dataset is CDLA-Sharing-1.0. Its author documented that the initial Hugging Face dataset rows split some stories across multiple rows, and pointed to the story-aligned `skeskinen/TinyStories-hf` conversion. This helper uses the latter representation but records the original dataset/license in the provenance. See:

- https://huggingface.co/datasets/roneneldan/TinyStories/discussions/2
- https://huggingface.co/datasets/skeskinen/TinyStories-hf
- https://huggingface.co/docs/dataset-viewer/en/rows

The derivative copy's README does not appear to restate a new license. Treat the **underlying original data as CDLA-Sharing-1.0**, not MIT, Apache, or CC0. Review the license/attribution obligations before publishing copied story data or manifests.

## Windows setup (PowerShell)

1. Extract the helper ZIP.
2. Change to your existing Genesis working directory:

```powershell
Set-Location 'C:\Users\jpowe\Downloads\genesis_native_seed\genesis_native_seed'
$python = 'C:\Users\jpowe\Downloads\genesis_native_seed\.venv\Scripts\python.exe'
```

3. Copy `fetch_tinystories_subset.py` from the extracted helper to this directory, without touching any existing checkpoint.
4. Run the small download (approximately 1 MB of **raw text only**, split 90% train / 5% validation / 5% test):

```powershell
& $python .\fetch_tinystories_subset.py --output data\genesis_v0_6_tinystories_1mb --target-bytes 1000000 --seed 42
if ($LASTEXITCODE -ne 0) { throw 'Corpus generation failed; do not train' }
```

The downloader uses the public Hugging Face **Dataset Viewer `/rows` HTTP API** in batches of up to 100, with a small delay and bounded retries. It samples entire stories rather than generating repetitions of 25 templates. It enforces separate source rows for held-out splits, normalized exact-text deduplication, and file-level SHA-256 provenance. It does **not** yet guarantee near-duplicate exclusion; that requires additional checks before claiming robust generalization.

It refuses to overwrite a nonempty output folder. If the server rate-limits or the connection fails, keep the partial output as evidence and use a new output path on retry; there is no resume feature in this prototype.

## Verify your existing code and intended training options

```powershell
& $python -m unittest discover -s tests -v
if ($LASTEXITCODE -ne 0) { throw 'Genesis tests failed; do not train' }
& $python -m genesis_seed.train_corpus --help
```

**Important:** The command from the earlier handoff used the wrong v0.5 dataset and gave `--output` a native export folder. The corpus trainer originally expects a **`.pt` checkpoint file**, not a native inference directory; this should be confirmed against the current local v0.6 code before invoking it.

## Small-model training smoke test (after checks pass)

Provided the local trainer still accepts `--layers` as reported for v0.4:

```powershell
& $python -m genesis_seed.train_corpus `
  --manifest data\genesis_v0_6_tinystories_1mb\manifest.json `
  --output checkpoints\genesis_v0_6_486k.pt `
  --width 128 --layers 2 --steps 100 --batch-size 4 `
  --context 128 --seed 42 --lr 0.001 --device cpu
if ($LASTEXITCODE -ne 0) { throw 'First training experiment failed' }

& $python -m genesis_seed.export_native `
  --checkpoint checkpoints\genesis_v0_6_486k.pt `
  --output models\native_v0_6_486k
if ($LASTEXITCODE -ne 0) { throw 'Model export failed' }

& $python -m genesis_seed.cli_native --model models\native_v0_6_486k text 'Once upon a time'
```

Do not treat 100 optimizer steps as sufficient for generalized language or as completion of v0.6. First measure seconds per step and validation loss, then run longer experiments with **separate checkpoints**. Preserve `v0.5`, `v0.4`, and existing `v0.6` artifacts.

The test set should be evaluated **once after model selection**, not used to repeatedly choose models. Do not train on the test documents.

## Evidence boundaries

- This helper was syntax-checked and unit-tested with mocked API responses (offline tests passed).
- The public row endpoint, actual remote dataset contents, compatibility with the latest local v0.6 code, download throughput, and Dell training results **have not been executed in this environment**.
- If the API returns incomplete/truncated pages or changes revisions within a split, the helper aborts rather than silently claiming reproducibility.
- Generated metrics must not be presented as proof of learning until there are actual held-out evaluations and unedited generation samples.
