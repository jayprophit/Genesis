"""Offline tests for the bounded downloader, no network calls."""
import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import fetch_tinystories_subset as f


class TestTinyStoriesCorpus(unittest.TestCase):
    def test_clean(self):
        self.assertEqual(f.clean_story('hello\r\nworld  '), 'hello\nworld')

    def test_compiler(self):
        story = 'Once upon a time a child found a book and read it before dinner. ' * 4
        def fake_get_rows(split, offset, length=100, timeout=25):
            total = 2000
            rows = [{"row_idx": offset + i,
                     "row": {"text": story + f" Unique story identifier {split} {offset + i}."},
                     "truncated_cells": []}
                    for i in range(min(100, total-offset))]
            return {"rows": rows, "num_rows_total": total, "partial": False, "_revision": "hash123"}
        with tempfile.TemporaryDirectory() as tmp:
            with patch.object(f, 'get_rows', fake_get_rows):
                out = Path(tmp) / 'dataset'
                summary = f.build(out, 40_000, 42, 0)
                manifest = json.loads((out / 'manifest.json').read_text())
                splits = {x["split"] for x in manifest["documents"]}
                self.assertEqual(splits, {"train", "validation", "test"})
                self.assertEqual(summary["dataset_revisions"]["train"], 'hash123')
                self.assertTrue(all((out / x["file"]).is_file() for x in manifest["documents"]))
                self.assertTrue(all(x["license"].startswith('CDLA-Sharing-1.0') for x in manifest["documents"]))
                self.assertEqual(len(set(x["sha256"] for x in manifest["documents"])), len(manifest["documents"]))
                with self.assertRaises(FileExistsError):
                    f.build(out, 40_000, 42, 0)

if __name__ == '__main__':
    unittest.main()
